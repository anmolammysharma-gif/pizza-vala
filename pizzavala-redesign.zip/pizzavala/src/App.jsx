import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import BrandStory from "./components/BrandStory";
import Stats from "./components/Stats";
import Menu from "./components/Menu";
import FeaturedFood from "./components/FeaturedFood";
import WhyPizzaVala from "./components/WhyPizzaVala";
import Gallery from "./components/Gallery";
import Experience from "./components/Experience";
import FinalCTA from "./components/FinalCTA";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

function App() {
  return (
    <div className="bg-cream text-charcoal">
      <Navbar />
      <main>
        <Hero />
        <BrandStory />
        <Stats />
        <Menu />
        <FeaturedFood />
        <WhyPizzaVala />
        <Gallery />
        <Experience />
        <FinalCTA />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
