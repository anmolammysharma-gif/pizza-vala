import { motion } from "framer-motion";

export default function BrandStory() {
  return (
    <section id="story" className="bg-cream py-24 md:py-32">
      <div className="container-vala grid md:grid-cols-12 gap-12 md:gap-8 items-start">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="md:col-span-6"
        >
          <h2 className="font-display font-semibold leading-[0.95] text-4xl sm:text-5xl lg:text-6xl tracking-tight">
            INDIAN FLAVOURS.
            <br />
            REIMAGINED.
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.8, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
          className="md:col-span-6"
        >
          <div className="max-w-lg space-y-5 text-[1.05rem] leading-relaxed text-charcoal/80">
            <p>
              At PizzaVala, every slice tells a story of passion, spice and
              fresh dough. What began as a dream under a pizza franchise is
              now our very own brand, created by chefs who wanted to bring
              something truly different to the table.
            </p>
            <p>
              We roll fresh dough every day, craft signature sauces with a
              hint of Indian spice, and top it all with love and a little bit
              of magic. It's authentic pizza — with an Indian twist you'll
              crave again and again.
            </p>
          </div>

          <div className="mt-10 overflow-hidden rounded-2xl">
            <motion.img
              initial={{ scale: 1.1 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
              src="https://images.unsplash.com/photo-1532460734809-e7f8475ca917?auto=format&fit=crop&w=1200&q=80"
              alt="Fresh dough being hand-prepared at PizzaVala"
              className="w-full h-72 md:h-80 object-cover"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
