import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { business } from "../data/content";

export default function Contact() {
  const mapQuery = encodeURIComponent(business.address);

  return (
    <section id="contact" className="bg-charcoal text-cream py-24 md:py-32">
      <div className="container-vala grid md:grid-cols-12 gap-12 md:gap-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7 }}
          className="md:col-span-5"
        >
          <h2 className="font-display font-semibold text-4xl sm:text-5xl tracking-tight">
            Get in touch
          </h2>
          <p className="mt-4 text-cream/70 max-w-sm">
            Visit us in Harrow, call ahead, or drop us a line — we're happy to
            help.
          </p>

          <ul className="mt-10 space-y-6">
            <li className="flex items-start gap-4">
              <MapPin size={20} className="mt-0.5 text-gold shrink-0" />
              <span className="text-cream/90">{business.address}</span>
            </li>
            <li className="flex items-start gap-4">
              <Phone size={20} className="mt-0.5 text-gold shrink-0" />
              <a href={business.phoneHref} className="text-cream/90 hover:text-cream">
                {business.phone}
              </a>
            </li>
            <li className="flex items-start gap-4">
              <Mail size={20} className="mt-0.5 text-gold shrink-0" />
              <a href={business.emailHref} className="text-cream/90 hover:text-cream break-all">
                {business.email}
              </a>
            </li>
            <li className="flex items-start gap-4">
              <Clock size={20} className="mt-0.5 text-gold shrink-0" />
              <span className="text-cream/90">
                See our latest hours via the order page below
              </span>
            </li>
          </ul>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="md:col-span-7"
        >
          <div className="overflow-hidden rounded-3xl border border-charcoal-line h-80 md:h-full min-h-80">
            <iframe
              title={`Map showing ${business.name}, ${business.address}`}
              src={`https://www.google.com/maps?q=${mapQuery}&output=embed`}
              className="w-full h-full grayscale-[15%] contrast-[1.05]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
