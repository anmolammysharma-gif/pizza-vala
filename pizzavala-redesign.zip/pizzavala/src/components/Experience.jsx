import { motion } from "framer-motion";

export default function Experience() {
  return (
    <section id="experience" className="bg-cream py-24 md:py-32">
      <div className="container-vala grid md:grid-cols-12 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8 }}
          className="md:col-span-5"
        >
          <h2 className="font-display font-semibold leading-[0.95] text-4xl sm:text-5xl tracking-tight">
            MORE THAN
            <br />
            JUST PIZZA.
          </h2>
          <p className="mt-6 text-charcoal/75 text-lg leading-relaxed max-w-md">
            PizzaVala brings together Indian style pizza, live puff
            preparation and authentic Indian street food under one roof —
            discover our exceptional range and enjoy street food that
            tantalises your taste buds, all in Harrow.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="md:col-span-7 overflow-hidden rounded-3xl"
        >
          <img
            src="https://images.unsplash.com/photo-1751560455942-f859f1215826?auto=format&fit=crop&w=1400&q=80"
            alt="Indian street food plated fresh, ready to be enjoyed"
            className="w-full h-[340px] md:h-[460px] object-cover"
          />
        </motion.div>
      </div>
    </section>
  );
}
