import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { ORDER_URL } from "../data/content";

export default function FeaturedFood() {
  return (
    <section className="relative bg-charcoal text-cream">
      <div className="grid md:grid-cols-2 min-h-[80vh]">
        <div className="relative order-2 md:order-1 h-[50vh] md:h-auto overflow-hidden">
          <motion.img
            initial={{ scale: 1.15 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
            src="https://images.unsplash.com/photo-1593504049359-74330189a345?auto=format&fit=crop&w=1400&q=80"
            alt="Freshly baked Indian style pizza, melted cheese and spiced toppings"
            className="h-full w-full object-cover"
          />
        </div>

        <div className="order-1 md:order-2 flex items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="container-vala md:pl-16 lg:pl-20 md:pr-12 py-16 md:py-0 max-w-xl"
          >
            <h2 className="font-display font-semibold leading-[0.95] text-4xl sm:text-5xl lg:text-6xl tracking-tight">
              BIG FLAVOUR.
              <br />
              FRESHLY MADE.
            </h2>
            <p className="mt-6 text-cream/75 text-lg leading-relaxed">
              Every base is rolled fresh, every sauce built in-house with a
              hint of Indian spice, every topping added by hand. It's pizza
              the way we always thought it should taste.
            </p>
            <a
              href={ORDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-9 inline-flex items-center gap-2 rounded-full bg-red px-7 py-3.5 text-sm font-semibold text-cream hover:bg-red-dark transition-colors"
            >
              Order Now
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
