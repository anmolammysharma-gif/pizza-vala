import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { ORDER_URL } from "../data/content";

export default function FinalCTA() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1650208485499-cf19056448b2?auto=format&fit=crop&w=1600&q=80"
          alt=""
          aria-hidden="true"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal/80" />
      </div>

      <div className="relative container-vala py-28 md:py-36 text-center">
        <motion.h2
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8 }}
          className="font-display font-semibold text-4xl sm:text-5xl lg:text-6xl tracking-tight text-cream leading-[0.95]"
        >
          READY FOR YOUR
          <br />
          NEXT SLICE?
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="mt-5 text-cream/75 text-lg"
        >
          Discover PizzaVala's Indian-inspired flavours.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, delay: 0.3 }}
        >
          <a
            href={ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="group mt-9 inline-flex items-center gap-2 rounded-full bg-red px-8 py-4 text-sm font-semibold text-cream hover:bg-red-dark transition-colors"
          >
            Order Now
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
