import { nav, business, ORDER_URL } from "../data/content";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-charcoal text-cream border-t border-charcoal-line">
      <div className="container-vala py-14 grid sm:grid-cols-2 md:grid-cols-4 gap-10">
        <div>
          <p className="font-display text-xl font-semibold">
            Pizza<span className="text-red">Vala</span>
          </p>
          <p className="mt-3 text-sm text-cream/60 max-w-xs">
            Indian style pizza, live puffs and street food, made fresh in
            Harrow.
          </p>
        </div>

        <div>
          <p className="text-sm font-semibold text-cream/90 mb-4">Navigate</p>
          <ul className="space-y-2.5 text-sm text-cream/60">
            {nav.map((item) => (
              <li key={item.href}>
                <a href={item.href} className="hover:text-cream transition-colors">
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="text-sm font-semibold text-cream/90 mb-4">Contact</p>
          <ul className="space-y-2.5 text-sm text-cream/60">
            <li>{business.address}</li>
            <li>
              <a href={business.phoneHref} className="hover:text-cream transition-colors">
                {business.phone}
              </a>
            </li>
            <li>
              <a href={business.emailHref} className="hover:text-cream transition-colors break-all">
                {business.email}
              </a>
            </li>
          </ul>
        </div>

        <div>
          <p className="text-sm font-semibold text-cream/90 mb-4">Order</p>
          <a
            href={ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center rounded-full bg-red px-5 py-2.5 text-sm font-semibold hover:bg-red-dark transition-colors"
          >
            Order Now
          </a>
        </div>
      </div>

      <div className="border-t border-charcoal-line">
        <div className="container-vala py-5 text-xs text-cream/45">
          © {year} PizzaVala. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
