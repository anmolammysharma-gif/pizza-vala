import { motion } from "framer-motion";
import { gallery } from "../data/content";

// asymmetric spans for a modern editorial mosaic (not a uniform IG grid)
const spans = [
  "md:col-span-7 md:row-span-2 aspect-[4/5] md:aspect-auto",
  "md:col-span-5 aspect-[4/3]",
  "md:col-span-5 aspect-[4/3]",
  "md:col-span-4 aspect-square",
  "md:col-span-4 aspect-square",
  "md:col-span-4 aspect-square",
];

export default function Gallery() {
  return (
    <section className="bg-charcoal text-cream py-24 md:py-32">
      <div className="container-vala">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7 }}
          className="font-display font-semibold text-4xl sm:text-5xl tracking-tight max-w-xl"
        >
          From the kitchen
        </motion.h2>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-12 md:grid-rows-2 gap-4 md:gap-5">
          {gallery.map((img, i) => (
            <motion.div
              key={img.src}
              initial={{ opacity: 0, scale: 0.96 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, delay: (i % 3) * 0.08 }}
              className={`relative overflow-hidden rounded-2xl ${spans[i] ?? "aspect-square"}`}
            >
              <img
                src={`${img.src}?auto=format&fit=crop&w=1000&q=80`}
                alt={img.alt}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-700 ease-out hover:scale-[1.04]"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
