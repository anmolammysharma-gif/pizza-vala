import { motion } from "framer-motion";
import { ArrowRight, UtensilsCrossed } from "lucide-react";
import { ORDER_URL } from "../data/content";

const headline = ["INDIAN SOUL.", "PIZZA ATTITUDE."];

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.12, delayChildren: 0.15 },
  },
};

const line = {
  hidden: { y: "110%" },
  show: { y: "0%", transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] } },
};

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-[100svh] bg-charcoal text-cream overflow-hidden flex items-center pt-28 pb-16 md:pt-32"
    >
      {/* subtle warm glow, decorative only */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 -right-40 h-[520px] w-[520px] rounded-full bg-red/20 blur-[120px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-0 left-0 h-[380px] w-[380px] rounded-full bg-gold/10 blur-[100px]"
      />

      <div className="container-vala relative grid md:grid-cols-12 gap-10 md:gap-6 items-center">
        <div className="md:col-span-6 lg:col-span-6">
          <motion.h1
            variants={container}
            initial="hidden"
            animate="show"
            className="font-display font-semibold leading-[0.95] text-[13vw] sm:text-6xl lg:text-[4.6rem] tracking-tight"
          >
            {headline.map((word) => (
              <span key={word} className="block overflow-hidden">
                <motion.span variants={line} className="block">
                  {word}
                </motion.span>
              </span>
            ))}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.65 }}
            className="mt-6 max-w-md text-base md:text-lg text-cream/75 leading-relaxed"
          >
            What began as a dream under a pizza franchise is now our very own
            brand. We roll fresh dough every day and craft signature sauces
            with a hint of Indian spice — authentic pizza with a twist you'll
            crave again and again.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.8 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href={ORDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 rounded-full bg-red px-7 py-3.5 text-sm font-semibold text-cream hover:bg-red-dark transition-colors"
            >
              Order Now
              <ArrowRight
                size={16}
                className="transition-transform group-hover:translate-x-1"
              />
            </a>
            <a
              href="#menu"
              className="inline-flex items-center gap-2 rounded-full border border-cream/30 px-7 py-3.5 text-sm font-semibold text-cream hover:border-cream/70 transition-colors"
            >
              <UtensilsCrossed size={16} />
              Explore Menu
            </a>
          </motion.div>
        </div>

        <div className="md:col-span-6 lg:col-span-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="relative mx-auto max-w-md md:max-w-none"
          >
            <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem]">
              <motion.img
                initial={{ scale: 1.15 }}
                animate={{ scale: 1 }}
                transition={{ duration: 1.6, ease: [0.22, 1, 0.36, 1] }}
                src="https://images.unsplash.com/photo-1650208485499-cf19056448b2?auto=format&fit=crop&w=1200&q=80"
                alt="Indian style pizza fresh from the PizzaVala kitchen, topped with spiced ingredients"
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/50 via-transparent to-transparent" />
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.1 }}
              className="absolute -bottom-6 -left-4 sm:left-6 rounded-2xl bg-cream text-charcoal px-5 py-4 shadow-xl max-w-[220px]"
            >
              <p className="font-display text-2xl font-semibold text-red">45</p>
              <p className="text-xs text-charcoal/70 mt-0.5">
                spiced flavours, all made in-house
              </p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
