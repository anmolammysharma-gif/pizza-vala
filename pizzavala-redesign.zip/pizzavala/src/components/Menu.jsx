import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { categories, ORDER_URL } from "../data/content";

export default function Menu() {
  return (
    <section id="menu" className="bg-cream py-24 md:py-32">
      <div className="container-vala">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7 }}
          className="max-w-2xl mb-14 md:mb-16"
        >
          <h2 className="font-display font-semibold text-4xl sm:text-5xl tracking-tight">
            What we're known for
          </h2>
          <p className="mt-4 text-charcoal/70 text-lg">
            Three kitchens in one — pizza, puff and street food, all made
            fresh and finished with PizzaVala's signature spice.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6 md:gap-8">
          {categories.map((cat, i) => (
            <motion.a
              key={cat.id}
              href={ORDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.7, delay: i * 0.08 }}
              whileHover="hover"
              className={`group relative block overflow-hidden rounded-3xl bg-charcoal ${
                i === 0 ? "md:col-span-2 md:row-span-1" : ""
              }`}
            >
              <div
                className={`relative overflow-hidden ${
                  i === 0 ? "aspect-[16/9] md:aspect-[21/9]" : "aspect-[4/5]"
                }`}
              >
                <motion.img
                  variants={{ hover: { scale: 1.06 } }}
                  transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                  src={`${cat.image}?auto=format&fit=crop&w=1400&q=80`}
                  alt={cat.title}
                  className="h-full w-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/10 to-transparent" />
              </div>

              <motion.div
                variants={{ hover: { y: -6 } }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="absolute inset-x-0 bottom-0 p-6 md:p-8 flex items-end justify-between gap-4"
              >
                <div>
                  <span className="text-xs uppercase tracking-wide text-gold">
                    {cat.tag}
                  </span>
                  <h3 className="mt-1 font-display text-2xl md:text-3xl font-semibold text-cream">
                    {cat.title}
                  </h3>
                  <p className="mt-2 max-w-md text-sm text-cream/70 hidden sm:block">
                    {cat.description}
                  </p>
                </div>
                <motion.span
                  variants={{ hover: { x: 4, y: -4 } }}
                  transition={{ duration: 0.35 }}
                  className="shrink-0 rounded-full bg-cream/10 p-3 text-cream group-hover:bg-cream/20"
                >
                  <ArrowUpRight size={20} />
                </motion.span>
              </motion.div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
