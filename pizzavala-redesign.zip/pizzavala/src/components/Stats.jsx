import { motion } from "framer-motion";
import { stats } from "../data/content";

export default function Stats() {
  return (
    <section className="bg-charcoal text-cream">
      <div className="container-vala py-16 md:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-charcoal-line">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.6 }}
              transition={{ duration: 0.6, delay: i * 0.12 }}
              className="py-8 sm:py-0 sm:px-8 first:pl-0 text-center sm:text-left"
            >
              <p className="font-display text-5xl md:text-6xl font-semibold text-gold">
                {stat.value}
              </p>
              <p className="mt-2 text-sm md:text-base text-cream/70">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
