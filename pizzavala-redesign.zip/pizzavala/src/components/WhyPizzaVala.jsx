import { motion } from "framer-motion";
import { Flame, Sparkles, Wheat, Heart } from "lucide-react";
import { whyPoints } from "../data/content";

const icons = [Wheat, Flame, Sparkles, Heart];

export default function WhyPizzaVala() {
  return (
    <section className="bg-cream py-24 md:py-32">
      <div className="container-vala">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7 }}
          className="font-display font-semibold text-4xl sm:text-5xl tracking-tight max-w-xl"
        >
          Why PizzaVala
        </motion.h2>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-10 md:gap-8">
          {whyPoints.map((point, i) => {
            const Icon = icons[i % icons.length];
            return (
              <motion.div
                key={point.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className="border-t border-charcoal-line pt-6"
              >
                <Icon size={26} strokeWidth={1.5} className="text-red" />
                <h3 className="mt-4 font-display text-lg font-semibold">
                  {point.title}
                </h3>
                <p className="mt-2 text-sm text-charcoal/70 leading-relaxed">
                  {point.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
