// All facts below are sourced from pizzavala.co.uk (home, /menu/, /contact-us/)
// and the live ordering site pizzavalaharrow.co.uk. Nothing here is invented —
// edit this file if any detail on the real site changes.

export const ORDER_URL = "https://pizzavalaharrow.co.uk/";

export const business = {
  name: "PizzaVala",
  location: "Harrow",
  phone: "020 3015 6449",
  phoneHref: "tel:02030156449",
  email: "harrow@pizzavala.co.uk",
  emailHref: "mailto:harrow@pizzavala.co.uk",
  address: "176 Station Road, Harrow, HA1 2RH",
};

export const stats = [
  { value: "6K+", label: "Happy Customers" },
  { value: "45", label: "Flavours Offered" },
  { value: "2", label: "Years in Business" },
];

export const categories = [
  {
    id: "pizzas",
    title: "Indian Style Pizzas",
    tag: "Signature",
    description:
      "Traditional Indian spices meet classic pizza craft — fresh dough, signature sauces and toppings with a spiced, unmistakably PizzaVala edge.",
    image: "https://images.unsplash.com/photo-1650208485499-cf19056448b2",
  },
  {
    id: "puffs",
    title: "Live Puff Preparation",
    tag: "Made to order",
    description:
      "Watch our chefs fold and fry each puff in front of you — crisp on the outside, soft and spiced within, straight from the pan to your hands.",
    image: "https://images.unsplash.com/photo-1747008624832-e068ee496908",
  },
  {
    id: "street-food",
    title: "Indian Street Food",
    tag: "From the streets",
    description:
      "The flavours of India's roadside stalls, brought to Harrow — bold, fast and full of the spice and spirit street food is loved for.",
    image: "https://images.unsplash.com/photo-1753357303396-704b5abe8945",
  },
];

export const whyPoints = [
  {
    title: "Fresh Dough, Every Day",
    description: "We roll fresh dough every day, the base every PizzaVala order starts from.",
  },
  {
    title: "Indian Spices, Signature Sauces",
    description: "Our sauces are crafted in-house with a hint of Indian spice, built for an authentic twist.",
  },
  {
    title: "Our Own Brand",
    description: "What began under a pizza franchise is now our own brand, built by chefs chasing something different.",
  },
  {
    title: "Made With Passion",
    description: "Every slice is made with love and a little bit of magic, from dough to topping.",
  },
];

export const gallery = [
  { src: "https://images.unsplash.com/photo-1650208485499-cf19056448b2", alt: "Indian style pizza, top-down view with spiced toppings" },
  { src: "https://images.unsplash.com/photo-1753357303396-704b5abe8945", alt: "Indian street food served fresh" },
  { src: "https://images.unsplash.com/photo-1747008624832-e068ee496908", alt: "Crisp, freshly fried puffs" },
  { src: "https://images.unsplash.com/photo-1559658166-be35cc5eb9cb", alt: "Assorted Indian spices used in PizzaVala sauces" },
  { src: "https://images.unsplash.com/photo-1532460734809-e7f8475ca917", alt: "Fresh dough being hand-prepared" },
  { src: "https://images.unsplash.com/photo-1751560455942-f859f1215826", alt: "Indian street food plate, fresh and ready" },
];

export const nav = [
  { label: "Home", href: "#home" },
  { label: "Our Story", href: "#story" },
  { label: "Menu", href: "#menu" },
  { label: "Experience", href: "#experience" },
  { label: "Contact", href: "#contact" },
];
